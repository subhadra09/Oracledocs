alter system kill session '1732,43612' immediate;
alter system kill session '1743,43554' immediate;
alter system kill session '2466,62089' immediate;
alter system kill session '1350,2448' immediate;
alter system kill session '1355,62482' immediate;
alter system kill session '1170,15811' immediate;
alter system kill session '1731,62969' immediate;
