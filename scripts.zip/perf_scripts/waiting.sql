set pages 100
set lines 132
col sid format 99999
col spid format A8
col event format a31 trunc
col bl_sess format 99999
col seconds_in_wait format 99999 heading 'SEC_IN_WAIT'
col last_call_et format 9999999 heading 'L_CALL_ET'
col action format a5 trunc
col spid format a5
col wait_time format 99999
col process format a6
col wait_object format a30
col prog format a20
select c.sid, (select spid  from v$process p where p.addr=c.paddr) spid,process,
       event, blocking_Session bl_sess , substr(module,instr(module,'/',-1)+1) prog  ,
                                  (select object_name
                                     from dba_objects o
                                    where o.object_id = c.row_wait_obj#) wait_object,
                           (select sum(a.value)
                           from v$sesstat a, v$statname b
                          where a.statistic# = b.statistic#
                                and a.sid=c.sid
                                and a.value != 0
                                and b.name like '%row%') sessrow
from v$session c
where event not in ('SQL*Net message from client','i/o slave wait','rdbms ipc message','pipe get');
