set markup html on
spool JAN24_Conc_Request_out2.csv
set timing on
set linesize 120
set pagesize 300
select r.REQUEST_ID, u.user_name, p.USER_CONCURRENT_PROGRAM_NAME PROGRAM,
DECODE(r.STATUS_CODE, 'A','Waiting','B','B=Resuming','C','C=Normal',
'D','D=Cancelled','E','E=Error','G','G=Warning',
'H','H=On Hold','I','I=Normal','M','M=No Manager',
'P','P=Scheduled','Q','Q=Standby','R','R=Normal',
'S','S=Suspended','T','T=Terminating','U','U=Disabled',
'W','W=Paused','X','X=Terminated','Z','Z=Waiting') STATUS,
DECODE(r.PHASE_CODE, 'C','Completed','I','I=Inactive','P','P=Pending','R','R=Running') PHASE,
r.ACTUAL_START_DATE STARTED, r.ACTUAL_COMPLETION_DATE COMPLETED,
ROUND((r.actual_completion_date - r.actual_start_date)*1440, 2) TOTAL_MINS,
FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)||':hrs '||
FLOOR((((r.actual_completion_date-r.actual_start_date)*24*60*60)-
FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)*3600)/60)||':Mins '||
ROUND((((r.actual_completion_date-r.actual_start_date)*24*60*60)-
FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)*3600-
(FLOOR((((r.actual_completion_date-r.actual_start_date)*24*60*60)-
FLOOR(((r.actual_completion_date-r.actual_start_date)*24*60*60)/3600)*3600)/60)*60)))||':Secs' TIME_TO_RUN,
r.ARGUMENT_TEXT ARGUMENTS
FROM fnd_concurrent_requests r, FND_CONCURRENT_PROGRAMS_TL p, fnd_concurrent_programs c, fnd_user u
WHERE r.CONCURRENT_PROGRAM_ID = p.CONCURRENT_PROGRAM_ID and r.requested_by = u.user_id
and p.CONCURRENT_PROGRAM_ID = c.CONCURRENT_PROGRAM_ID
and r.ACTUAL_START_DATE like '%-JAN-24'
AND p.language = 'US'
and r.ACTUAL_COMPLETION_DATE is not null
order by r.ACTUAL_START_DATE desc;
set timing off
set markup html off
spool off
