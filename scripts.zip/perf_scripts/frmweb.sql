set pages 300 lines 300
select 'alter system kill session ' || '''' || sid || ',' || serial# || '''' || ' immediate;' from v$session where status='INACTIVE' and last_call_et>3600*3 and EVENT='SQL*Net message from client' and PROGRAM like 'frmweb%';

