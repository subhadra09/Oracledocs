alter system kill session '1562,50871' immediate;
alter system kill session '2862,17501' immediate;
alter system kill session '608,31636' immediate;
alter system kill session '1718,62190' immediate;
