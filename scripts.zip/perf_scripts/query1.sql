select  GLJH.Je_Header_Id                                            
       ,GLJH.Doc_Sequence_Value                                      
       ,GLJL.Je_Line_Num                                            
       ,GLJH.Je_Source
       ,GJC.User_Je_Category_Name                                             
       ,GLCC.Code_Combination_Id                                   
       ,GLCC.Segment1 COMPANY                                                
       ,GLCC.Segment2                                                
       ,GLCC.Segment3                                                
       ,GLCC.Segment7                                                
       ,GLCC.Segment4                                               
       ,GLCC.Segment8                                                
       ,GLJH.Currency_Code Journal_Currency_Code                      
       ,GLJL.Entered_Dr                                              
       ,GLJL.Entered_Cr                                             
       ,GLSB.Currency_Code Batch_Currency_Code                                        
       ,GLJL.Accounted_Dr                                            
       ,GLJL.Accounted_Cr                                            
       ,GLJB.Name Batch_Name                                                
       ,GLJL.Description Line_Description                                                
       ,GLJH.Creation_Date                                           
       ,GLJH.Period_Name                                             
       ,FNDU.User_Name                                               
       ,GLJH.Posted_Date                                            
       ,GLSB.Name Ledger_Name                                               
       ,FFVV.Description  Account_Description                                           
       ,nvl(N.Accounted_Dr,0) Acct_Dr
       ,nvl(N.Accounted_Cr,0) Acct_Cr
       ,nvl(N.Accounted_Dr,0)-nvl(N.Accounted_Cr,0) Net_Amount
       ,ENT.Transaction_Number
       ,ENT.Security_Id_Int_1 Org_Id
       ,N.Description
       ,ENT.Entity_Code
       ,XAH.Ae_Header_Id 
       ,N.Accounting_Class_Code
       ,AP.Vendor_Name
       ,AP.Vendor_No
       ,AP.Trx_Date
	   ,GLJH.Default_Effective_Date
	   ,N.AE_LINE_NUM
from    APPS.GL_JE_HEADERS             GLJH
       ,APPS.GL_JE_LINES               GLJL
       ,APPS.GL_JE_BATCHES             GLJB
       ,APPS.GL_CODE_COMBINATIONS      GLCC
       ,APPS.FND_USER                  FNDU
       ,APPS.GL_LEDGERS                GLSB
       ,APPS.GL_JE_CATEGORIES          GJC
       ,APPS.FND_FLEX_VALUES_VL        FFVV
       ,APPS.GL_IMPORT_REFERENCES      M
       ,XLA.XLA_AE_LINES               N
       ,XLA.XLA_AE_HEADERS             XAH
       ,XLA.XLA_TRANSACTION_ENTITIES   ENT
       ,(select 'AP_INVOICES'    type,
                AIA.Invoice_Id   Source_Id,
                AIA.Invoice_Date Trx_Date,
                ASP.Vendor_Name, 
                ASP.Segment1     Vendor_No
           from APPS.AP_INVOICES_ALL AIA, 
                APPS.AP_SUPPLIERS    ASP 
          where ASP.Vendor_Id = AIA.Vendor_Id
          union
          select 'AP_PAYMENTS', 
                 ACA.Check_Id,
                 ACA.Check_Date,
                 APS.Vendor_Name,
                 APS.Segment1
            from APPS.AP_CHECKS_ALL ACA,
                 APPS.AP_SUPPLIERS  APS
           where ACA.Vendor_Id = APS.Vendor_Id) AP
where   1 = 1
and     GLJH.Je_Header_Id         =   GLJL.Je_Header_Id
and     M.Je_Header_Id            =   GLJH.Je_Header_Id
and     GLJL.Je_Line_Num          =   M.Je_Line_Num
and     GLJL.Code_Combination_Id  =   GLCC.Code_Combination_Id
and     GLJH.Je_Batch_Id          =   GLJB.Je_Batch_Id
and     GJC.Je_Category_Name      =   GLJH.Je_Category
and     GLJH.Created_By           =   FNDU.User_Id
and     ENT.Source_Id_Int_1       =   AP.Source_Id
and     DECODE(XAH.JE_CATEGORY_NAME,'Purchase Invoices','AP_INVOICES','Payments','AP_PAYMENTS',ENT.Entity_code) =   AP.Type
and     GLSB.Ledger_Id            =   GLJH.Ledger_Id
and     GLCC.Segment2             =   FFVV.Flex_Value
and     M.Gl_Sl_Link_Id           =   N.Gl_Sl_Link_Id
and     M.Gl_Sl_Link_Table        =   N.Gl_Sl_Link_Table
and     N.Ae_Header_Id            =   XAH.Ae_Header_Id
AND     ENT.Application_Id        =   XAH.Application_Id
AND     ENT.Entity_Id             =   XAH.Entity_Id
and     GLJH.Je_Category          <>  'Consolidation'
and     GLJH.Je_Source            =   'Payables'
and     FFVV.Flex_Value_Set_Id    =   '1013317'
and     GLCC.Segment1  in ('2500','8100')
and     GLJH.Default_Effective_Date between to_date('01-FEB-2023', 'DD-MON-YYYY') and to_date('28-FEB-2023', 'DD-MON-YYYY')  
union
select  GLJH.Je_Header_Id                                            
       ,GLJH.Doc_Sequence_Value                                      
       ,GLJL.Je_Line_Num                                             
       ,GLJH.Je_Source                                             
       ,GJC.User_Je_Category_Name                                             
       ,GLCC.Code_Combination_Id                                     
       ,GLCC.Segment1                                                
       ,GLCC.Segment2                                                
       ,GLCC.Segment3                                                
       ,GLCC.Segment7                                                
       ,GLCC.Segment4                                               
       ,GLCC.Segment8                                                
       ,GLJH.Currency_Code                                           
       ,GLJL.Entered_Dr                                              
       ,GLJL.Entered_Cr                                              
       ,GLSB.Currency_Code                                           
       ,GLJL.Accounted_Dr                                            
       ,GLJL.Accounted_Cr                                            
       ,GLJB.Name                                                   
       ,GLJL.Description                                                    
       ,GLJH.Creation_Date                                           
       ,GLJH.Period_Name                                             
       ,FNDU.User_Name                                               
       ,GLJH.Posted_Date                                             
       ,GLSB.Name                                                    
       ,FFVV.Description                                             
       ,GLJL.Accounted_Dr                                            
       ,GLJL.Accounted_Cr                                            
       ,NVL (GLJL.Accounted_Dr ,0) - NVL( GLJL.Accounted_Cr,0) 
       ,null
       ,null
       ,null          
       ,null                                                       
       ,null                                                        
       ,null                                                        
       ,null                                                         
       ,null                                                       
       ,null        
       ,GLJH.Default_Effective_Date	 
       ,null
from    APPS.GL_JE_HEADERS          GLJH
       ,APPS.GL_JE_LINES            GLJL
       ,APPS.GL_JE_BATCHES          GLJB
       ,APPS.GL_CODE_COMBINATIONS   GLCC
       ,APPS.FND_USER               FNDU
       ,APPS.GL_LEDGERS             GLSB
       ,APPS.GL_JE_CATEGORIES       GJC
       ,APPS.FND_FLEX_VALUES_VL     FFVV
where   GLJH.Je_Header_Id         =   GLJL.Je_Header_Id
and     GLJL.Code_Combination_Id  =   GLCC.Code_Combination_Id
and     GLJH.Je_Batch_Id          =   GLJB.Je_Batch_Id
and     GJC.Je_Category_Name      =   GLJH.Je_Category
and     GLJH.Created_By           =   FNDU.User_Id
and     GLSB.Ledger_Id            =   GLJH.Ledger_Id
and     GLCC.Segment2             =   FFVV.Flex_Value
and     GLJH.Je_Category         <>   'Consolidation'
and     GLJH.Je_Source           <>   'Payables'
and     FFVV.Flex_Value_Set_Id    =   1013317
and     GLCC.Segment1  in ('2500','8100')
and     GLJH.Default_Effective_Date between to_date('01-FEB-2023', 'DD-MON-YYYY') and to_date('28-FEB-2023', 'DD-MON-YYYY');

