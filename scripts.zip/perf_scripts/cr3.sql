-- Prompt at runtime for request_id
PROMPT Enter Request ID:

SELECT DISTINCT 
    r.request_id request,
    p.user_concurrent_program_name,
    d.inst_id,
    d.sid, 
    d.serial#,
    d.sql_id,
    d.sql_hash_value,
    m.plan_hash_value,
    d.event,
    c.spid,
    DECODE(r.phase_code,'C','Completed','I','Inactive','P','Pending','R','Running') phase,
    DECODE(r.status_code,'A','Waiting','B','Resuming','C','Normal','D','Cancelled',
                          'E','Error','F','Scheduled','G','Warning','H','On Hold',
                          'I','Normal','M','No Manager','Q','Standby','R','Normal',
                          'S','Suspended','T','Terminating','U','Disabled','W','Paused',
                          'X','Terminated','Z','Waiting') status,
    (SYSDATE - actual_start_date)*24*60 elapsed_minutes, 
    TO_CHAR(actual_start_date, 'MM/DD/YY HH24:MI') start_time, 
    q.user_concurrent_queue_name queue_name, 
    u.user_name
FROM apps.fnd_concurrent_queues_vl q,
     applsys.fnd_concurrent_processes cp, 
     applsys.fnd_concurrent_programs_tl p, 
     applsys.fnd_concurrent_requests r, 
     apps.fnd_user u, 
     gv$process c, 
     gv$session d, 
     gv$sqlarea m
WHERE r.request_id = &request_id
  AND p.application_id = r.program_application_id
  AND r.concurrent_program_id = p.concurrent_program_id
  AND cp.concurrent_process_id = r.controlling_manager
  AND cp.queue_application_id = q.application_id
  AND cp.concurrent_queue_id = q.concurrent_queue_id
  AND p.language = 'US'
  AND r.requested_by = u.user_id
  AND m.object_status = 'VALID'
  AND c.spid = r.oracle_process_id
  AND c.addr = d.paddr
  AND d.sql_id = m.sql_id
ORDER BY 13 DESC;
