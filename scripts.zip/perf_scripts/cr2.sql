set pagesize 1000 lines 300 feed on space 1
column user_concurrent_program_name format a58 trunc
column request format 9999999999
column total_time format 99,999.99
column start_time format a14
column node_name format a8 noprint
column queue_name  format a30 trunc
col user_name for a15
col event for a35
col spid for a9
select DISTINCT r.request_id request,p.user_concurrent_program_name,d.inst_id,d.sid, d.serial#,d.sql_id,d.sql_hash_value,m.plan_hash_value,d.event,c.spid,
decode(r.PHASE_CODE,'C','Completed','I','Inactive','P','Pending','R','Running') phase,
decode(r.Status_code,'A','Waiting','B','Resuming','C','Normal','D','Cancelled','E','Error','F','Scheduled','G','Warning','H','On Hold','I','Normal','M','No Manager','Q','Standby','R', 'Normal','S','Suspended','T','Terminating','U','Disabled','W','Paused','X','Terminated', 'Z','Waiting') status,
(sysdate-actual_start_date)*24*60 Time_min, to_char(actual_start_date, 'MM/DD/YY HH24:MI') start_time, q.user_concurrent_queue_name queue_name, u.user_name
from apps.fnd_concurrent_queues_vl q,applsys.fnd_concurrent_processes cp, applsys.fnd_concurrent_programs_tl p, applsys.fnd_concurrent_requests r, apps.fnd_user u, gv$process c, gv$session d,gv$sqlarea m
where r.PHASE_CODE = 'R'
and p.application_id = r.program_application_id
and r.concurrent_program_id = p.concurrent_program_id
and cp.CONCURRENT_PROCESS_ID = r.controlling_manager
and cp.QUEUE_APPLICATION_ID = q.application_id
and cp.CONCURRENT_QUEUE_ID = q.CONCURRENT_QUEUE_ID
and p.language='US'
and r.REQUESTED_BY = u.user_id
and m.object_status='VALID'
  AND    c.spid = r.oracle_process_id
  AND    c.addr = d.paddr
AND d.sql_id=m.sql_id
order by 13 desc;
