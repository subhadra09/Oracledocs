set linesize 152
    set pages 1000
    col username for a10
    col status for a10
    col phase for a10
    col PNAME for a15
    col mins for 99999
    col start_date for a18
    col end_date for a18
    
    col request_id for 99999999999
    select
    b.user_name username,
    request_id as REQ_ID,
    a.controlling_manager cm,
    decode(a.phase_code,
    'C','Complete',
    'I','Inactive',
    'P','Pending',
    'R','Running',
    'Unknown') phase_code ,
    decode(a.status_code,
    'C','Normal',
    'D','Cancelled',
    'E','Error',
    'F','Scheduled',
    'G','Warning',
    'I','Normal',
    'M','No Manager',
    'Q','Standby',
    'R','Normal',
    'S','Suspended',
    'T','Terminating',
    'U','Disabled',
    'W','Paused',
    'Z','Waiting'
    ) status_code ,
    a.USER_CONCURRENT_PROGRAM_NAME as PNAME,
    to_char(a.REQUESTED_START_DATE,'DD-MON-YY HH24-MI-SS') START_DATE,
    to_char(a.ACTUAL_COMPLETION_DATE,'DD-MON-YY HH24-MI-SS') END_DATE,
    (a.ACTUAL_COMPLETION_DATE - a.REQUESTED_START_DATE)*24*60 "mins"
    from
    apps.fnd_conc_req_summary_v a,
    apps.fnd_user b
    where
    --status_code in ('E') and
    upper(a.USER_CONCURRENT_PROGRAM_NAME) like upper('%&str%') and
    a.REQUESTED_BY=b.user_id
    and rownum<100order by ACTUAL_COMPLETION_DATE;

