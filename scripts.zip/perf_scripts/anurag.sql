select default_value from fnd_descr_flex_column_usages
where  descriptive_flexfield_name = '$SRS$.GETTY_AR_CREDIT_CARD_PROCESS'
  and    end_user_column_name = 'Verisign Server'
  and    default_value = 'X';
select default_value,default_type
from fnd_descr_flex_column_usages
where  descriptive_flexfield_name = '$SRS$.GETTY_AR_CREDIT_CARD_PROCESS'
  and    end_user_column_name = 'Credit Card';
select default_value,default_type from fnd_descr_flex_column_usages
where  descriptive_flexfield_name = '$SRS$.GETTY_AR_CREDIT_CARD_PROCESS'
  and    end_user_column_name = 'Expiration date';

