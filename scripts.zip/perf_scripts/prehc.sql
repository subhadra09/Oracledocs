set lines 200
col host_name for a17
col node_name for a30
col database for a10
col concmgr for a9
col forms for a7
col webserver for a11
col admin for a7
col SERVER_ADDRESS for a15
select NODE_NAME,SERVER_ADDRESS,
decode(STATUS,'Y','ACTIVE','INACTIVE') Status,
decode(SUPPORT_CP,'Y', 'YES','NO') ConcMgr,
decode(SUPPORT_FORMS,'Y','YES', 'NO') Forms,
decode(SUPPORT_WEB,'Y','YES', 'NO') WebServer,
decode(SUPPORT_ADMIN, 'Y','YES', 'NO') Admin,
decode(SUPPORT_DB, 'Y','YES', 'NO') Database
from apps.fnd_nodes where node_name != 'AUTHENTICATION' order by NODE_NAME;

set wrap on
set linesize 130;
col parameter_name format a30 head "Parameter Name"
col parameter_value format a50 head "Value"
SELECT
c.parameter_name,
a.parameter_value
FROM fnd_svc_comp_param_vals a,
fnd_svc_components b,
fnd_svc_comp_params_b c
WHERE b.component_id = a.component_id
AND b.component_type = c.component_type
AND c.parameter_id = a.parameter_id
AND c.encrypted_flag = 'N'
AND b.component_name = 'Workflow Notification Mailer'
ORDER BY c.parameter_name;

set linesize 120
set pagesize 500
col NODE_NAME for a25
column COMPONENT_NAME format a45
column STARTUP_MODE format a19
column COMPONENT_STATUS format a19
select fsc.COMPONENT_NAME ,fsc.STARTUP_MODE,fsc.COMPONENT_STATUS,fcq.NODE_NAME
from APPS.FND_CONCURRENT_QUEUES_VL fcq, fnd_svc_components fsc
where fsc.concurrent_queue_id = fcq.concurrent_queue_id(+)
order by COMPONENT_STATUS , STARTUP_MODE , COMPONENT_NAME;

set pages 150
set lines 120
col manager for a50
col ApId for 99999
col Q_Id for 99999
col node for a17
col RUNNING for 9999
col MAX for 999
col BUF for 999
select Application_Id ApId, concurrent_queue_id Q_Id,User_Concurrent_Queue_Name Manager,
Target_Node Node,Running_Processes Running, Max_Processes Max, Cache_Size Buf, Diagnostic_Level D
from fnd_concurrent_queues_vl where Running_Processes = Max_Processes and Running_Processes > 0;

set lines 100
col MANAGER format a50
SELECT TRIM(USER_CONCURRENT_QUEUE_NAME) "MANAGER", MAX_PROCESSES PROCESS FROM APPS.FND_CONCURRENT_QUEUES_VL WHERE (ENABLED_FLAG='Y' AND MAX_PROCESSES >0)ORDER BY DECODE (APPLICATION_ID, 0, DECODE (CONCURRENT_QUEUE_ID, 1, 1, 4, 2)), SIGN(MAX_PROCESSES) DESC,CONCURRENT_QUEUE_NAME,APPLICATION_ID;

