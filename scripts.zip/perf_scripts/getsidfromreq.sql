set lines 200
col host_name format a15
col instance_name format a15
col osuser format a10
col module format a30

SELECT a.request_id,s.status, s.sid, s.serial#, s.osuser, s.module, p.spid, s.sql_hash_value, i.instance_name, i.host_name
FROM gv$session s, gv$process p, gv$instance i, apps.fnd_concurrent_requests a
WHERE s.paddr = p.addr
AND p.spid = a.oracle_process_id
AND s.inst_id=p.inst_id
AND s.inst_id=i.inst_id
AND a.request_id = &Request_ID
AND s.module is not null
/

