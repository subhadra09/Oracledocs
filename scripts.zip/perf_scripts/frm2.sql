select v.MACHINE,v.port,v.PROGRAM, v.MODULE, v.ACTION, v.CLIENT_IDENTIFIER,v.state
from v$session v
where v.process = &1;

