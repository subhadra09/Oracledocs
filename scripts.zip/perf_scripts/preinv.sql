set pages 300 lines 300
select name,user,created,open_Mode from v$database;
select count(*) "Current Invalids Count " from dba_objects where status ='INVALID' ;
col OWNER for a30
col OBJECT_NAME for a50
select owner,object_type,count(*) from dba_objects where status='INVALID' group by owner,object_type;
create table Invalids_&tabname as  (select object_name,owner from dba_objects where status='INVALID') ;

host sleep 3

select count(*) "Invalids count From Bkp table " from Invalids_&tabname;
