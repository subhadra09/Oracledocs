SELECT   p.spid,s.username,s.sid,s.status,s.module,s.serial#,to_char(logon_time,'DD-MON-YYYY HH24:MI:SS')
FROM    v$process p, v$session s
WHERE   p.addr=s.paddr
AND    p.spid= '&1'
/

