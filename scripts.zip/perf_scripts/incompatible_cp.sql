set pages 300 lines 300
col USER_CONCURRENT_PROGRAM_NAME for a45
col TYPE for a16
col "Incompatibilty Type" for a30
col APPLICATION_NAME for a20
SELECT distinct fat.application_id,
                to_run_concurrent_program_id,
                fat.APPLICATION_NAME,
                fcpt.user_concurrent_program_name,
                DECODE(TO_RUN_TYPE, 'S', 'Set', 'Program') TYPE,
                DECODE(INCOMPATIBILITY_TYPE, 'G', 'Global', 'Domain') "Incompatibilty Type"
  FROM FND_CONCURRENT_PROGRAM_SERIAL fcps,
       FND_CONCURRENT_PROGRAMS_TL    fcpt,
       FND_APPLICATION_TL            fat
 WHERE fcps.RUNNING_APPLICATION_ID = fat.application_id
   AND fcpt.CONCURRENT_PROGRAM_ID = fcps.TO_RUN_CONCURRENT_PROGRAM_ID
   --AND fcpt.CONCURRENT_PROGRAM_ID in (select CONCURRENT_PROGRAM_ID from FND_CONCURRENT_PROGRAMS where concurrent_program_name='&shortname')
   AND fcpt.LANGUAGE = 'US'
   AND fat.LANGUAGE = 'US'
AND fcpt.user_concurrent_program_name like  '%&concurrent_program_name%'
 ORDER BY 1, 2;
