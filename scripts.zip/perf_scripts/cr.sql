set echo off pages 100 lines 202
column REQUEST heading 'Request' format a9
column PHASE heading 'Phase' format A8
column STATUS heading 'Status' format A8
column PROGRAM heading 'Program Name' format A45
column SHORT heading 'Short Name' format A15
column REQUESTOR heading 'Requestor' format A15
column START_TIME heading 'Start Time' format A15
column RUN_TIME justify left heading 'Time(e)' format 999999.9
column OSPID heading 'OSPID' format a7
column OS_PIDa heading 'OSPIDA' format a6
column process for a10;
column SID heading 'SID' format 99999
column serial# heading 'Serial#' format 99999
select distinct substr(fcrv.request_id,1,9)REQUEST,         decode(fcrv.phase_code,'P','Pending','R','Running','I','Inactive','Completed')PHASE,decode(fcrv.status_code,'A','Waiting',   'B','Resuming','C','Normal','F','Scheduled','G','Warning','H','On Hold','I','Normal','M','No Manager','Q','Standby','R','Normal','S','Suspended','T','Terminating','U','Disabled','W','Paused','X','Terminated','Z','Waiting',fcrv.status_code)STATUS, substr(fcrv.program,1,40)PROGRAM, substr(fcrv.PROGRAM_SHORT_NAME,1,15)SHORT, 
		substr(fcrv.requestor,1,15)REQUESTOR,
		round(((sysdate - fcrv.actual_start_date)*1440),1)RUN_TIME,
		substr(fcr.oracle_process_id,1,7)OSPID,
		s.sid,process,s.serial#
from    apps.fnd_conc_req_summary_v fcrv,
		apps.fnd_concurrent_requests fcr,
		gv$session s,
		gv$process p
where   fcrv.phase_code = 'R'
and     fcrv.request_id = fcr.request_id
and     s.paddr = p.addr
and     fcr.oracle_process_id = p.spid
and     fcrv.concurrent_program_id not in ('40112','40113','36887')
order by RUN_TIME;
